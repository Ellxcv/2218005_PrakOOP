/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author 62821
 */
public interface Processable {
    void processData(DefaultTableModel tableModel);
}
